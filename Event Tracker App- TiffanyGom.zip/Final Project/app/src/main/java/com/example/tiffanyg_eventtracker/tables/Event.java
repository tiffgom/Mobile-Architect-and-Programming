package com.example.tiffanyg_eventtracker.tables;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class is the table for the Event database which creates the constructor,
 *               getters, and setters for event entry parameters.
 */



public class Event {
    int id;
    String user_email;
    String date;
    String time;
    String description;

    public Event() {
        super();
    }

    // Constructor
    public Event(int i, String email, String date, String time, String description) {
        super();
        this.id = i;
        this.user_email = email;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    // Constructor (without id)
    public Event(String email, String date, String time, String description) {
        this.user_email = email;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    // Constructor (without id and email)
    public Event(String date, String time, String description) {
        this.date = date;
        this.time = time;
        this.description = description;
    }

    // Setters and Getters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
