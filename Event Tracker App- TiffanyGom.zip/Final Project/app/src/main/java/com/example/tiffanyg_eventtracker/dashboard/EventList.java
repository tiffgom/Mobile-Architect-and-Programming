package com.example.tiffanyg_eventtracker.dashboard;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tiffanyg_eventtracker.R;
import com.example.tiffanyg_eventtracker.databases.EventsSQL;
import com.example.tiffanyg_eventtracker.tables.Event;

import java.util.ArrayList;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class populates rows in the app's dashboard based on an event entry
 *               and displays the data based on stored positioning as well as the entry
 *               layout template. Each row includes an edit action icon that navigates to
 *               the modify dialogue box, the event's date/time/description, and an action
 *               icon that deletes the entire row.
 */



public class EventList extends BaseAdapter {

    private final Activity context;
    ArrayList<Event> events;
    EventsSQL db;
    private PopupWindow popupWindow;

    public EventList(Activity context, ArrayList<Event> events, EventsSQL db) {
        this.context = context;
        this.events = events;
        this.db = db;
    }
    // Access entry template layout to get entry data and existing positions
    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.activity_entries_template, null, true);

            vh.ButtonEdit = row.findViewById(R.id.buttonEditEvent);
            vh.textViewEventDate = row.findViewById(R.id.textViewEventDate);
            vh.textViewEventTime = row.findViewById(R.id.textViewEventTime);
            vh.textViewEventDescription = row.findViewById(R.id.textViewEventDescription);
            vh.ButtonDelete = row.findViewById(R.id.buttonDeleteAll);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.textViewEventDate.setText(events.get(position).getDate());
        vh.textViewEventTime.setText(events.get(position).getTime());
        vh.textViewEventDescription.setText(events.get(position).getDescription());

        // Send SMS if value equals 0
        String value = vh.textViewEventTime.getText().toString().trim();
        if (value.equals("0")) {
            EventDashActivity.SendSMSMessage(context.getApplicationContext());
        }

        final int positionPopup = position;

        // Edit button listener
        vh.ButtonEdit.setOnClickListener(view -> updateEntry(positionPopup));

        // Delete button listener
        vh.ButtonDelete.setOnClickListener(view -> {
            db.deleteEvent(events.get(positionPopup));
            events = (ArrayList<Event>) db.getAllEvents();
            notifyDataSetChanged();
            Toast.makeText(context, "Event has been deleted!", Toast.LENGTH_SHORT).show();
        });

        return row;
    }

    // To update the event list in the dashboard for position, entry ID, and table size.
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return events.size();
    }

    // Update an entry in the event list
    public void updateEntry(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_modify_event, context.findViewById(R.id.activity_modify_popup));
        // Entry at location of Modify Event pop up window
        popupWindow = new PopupWindow(layout, 800, 800, true);
        popupWindow.showAtLocation(layout, Gravity.CENTER, 0, 0);
        // Find components for entry
        final EditText editTextEditDate = layout.findViewById(R.id.editTextEditDate);
        final EditText editTextEditTime = layout.findViewById(R.id.editTextEditTime);
        final EditText editTextEditDescription = layout.findViewById(R.id.editTextEditDescription);

        editTextEditDate.setText(events.get(positionPopup).getDate());
        editTextEditTime.setText(events.get(positionPopup).getTime());
        editTextEditDescription.setText(events.get(positionPopup).getDescription());
        Button confirm = layout.findViewById(R.id.editEventConfirmButton);
        Button cancel = layout.findViewById(R.id.editEventCancelButton);

        // Activate fields to update entry
        confirm.setOnClickListener(view -> {
            String eventDate = editTextEditDate.getText().toString();
            String eventTime = editTextEditTime.getText().toString();
            String eventDescription = editTextEditDescription.getText().toString();

            Event event = events.get(positionPopup);
            event.setDate(eventDate);
            event.setTime(eventTime);
            event.setDescription(eventDescription);

            // Update database
            db.updateEvent(event);
            events = (ArrayList<Event>) db.getAllEvents();
            notifyDataSetChanged();

            // Display brief message notifying user of an update
            Toast.makeText(context, "Event has been updated!", Toast.LENGTH_SHORT).show();

            // Close pop up window
            popupWindow.dismiss();
        });

        // Activate pop up window cancel button
        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Event not modified.", Toast.LENGTH_SHORT).show();
            popupWindow.dismiss();
        });
    }

    public static class ViewHolder {
        TextView textViewEventDate;
        TextView textViewEventTime;
        TextView textViewEventDescription;
        ImageButton ButtonEdit;
        ImageButton ButtonDelete;
    }

}
