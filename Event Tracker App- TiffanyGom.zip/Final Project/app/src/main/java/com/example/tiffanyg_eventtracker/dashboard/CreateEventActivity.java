package com.example.tiffanyg_eventtracker.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tiffanyg_eventtracker.R;
import com.example.tiffanyg_eventtracker.databases.EventsSQL;
import com.example.tiffanyg_eventtracker.tables.Event;

import java.util.concurrent.atomic.AtomicReference;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class is for the activity New Event. Users will be able to tap the Add
 *               button on the bottom app bar in the dashboard to navigate to this screen.
 *               Users will be able to input the event date, time, and description and then return
 *               to the dashboard by either actioning the button to add and display the new
 *               event entry or cancel the action.
 */



public class CreateEventActivity extends AppCompatActivity {
    // Variables for New Event screen components
    String tempEmail, tempDate, tempTime, tempDescription;
    EditText valueDate, valueTime, valueDescription;
    Button buttonCancel, buttonAddEvent;
    Boolean emptyField;
    EventsSQL db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        // Initiate components
        valueDate = findViewById(R.id.editTextEditDate);
        valueTime = findViewById(R.id.editTextEditTime);
        valueDescription = findViewById(R.id.editTextEditDescription);
        buttonCancel = findViewById(R.id.addEventCancelButton);
        buttonAddEvent = findViewById(R.id.addEventAddButton);
        db = new EventsSQL(this);

        // Android Studio recommendation to automatically update to current value
        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Get email input
        tempEmail = intent.get().getStringExtra(EventDashActivity.UserEmail);

        // Activate cancel button and return to dashboard
        buttonCancel.setOnClickListener(view -> {
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Activate button that signifies user wishes to add data to dashboard
        buttonAddEvent.setOnClickListener(view -> addEvent());
    }

    // Add entry to database and display in dashboard
    public void addEvent() {
        String message = entryFields();    // Call function to check if field is empty
        // if input fields are not empty, then add new event
        if (!emptyField) {
            String date = tempDate;
            String time = tempTime;
            String description = tempDescription;
            Event event = new Event(date, time, description);
            db.createEvent(event);

            // Display brief message to inform user their entry was added
            Toast.makeText(this, "Event added!", Toast.LENGTH_LONG).show();

            // Return to dashboard
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        }
        // If a field/s is empty, display brief message informing user
        else {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }


    public String entryFields() {
        // Get and store field values as strings
        String message = "";
        tempDate = valueDate.getText().toString().trim();
        tempTime = valueTime.getText().toString().trim();
        tempDescription = valueDescription.getText().toString().trim();

        // Checking for null fields and customize message
        if (tempDate.isEmpty()) {
            valueDate.requestFocus();
            emptyField = true;
            message = "Please enter a  \"Date\".";
        }
        else if (tempTime.isEmpty()) {
            valueTime.requestFocus();
            emptyField = true;
            message = "Please enter a \"Time\".";
        }
        else if (tempDescription.isEmpty()) {
            valueDescription.requestFocus();
            emptyField = true;
            message = "Please enter a \"Description\".";
        }
        else {
            emptyField = false;
        }
        return message;
    }

}