package com.example.tiffanyg_eventtracker.login;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tiffanyg_eventtracker.R;
import com.example.tiffanyg_eventtracker.databases.UsersSQL;
import com.example.tiffanyg_eventtracker.tables.User;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class is for the activity screen that registers a new user. A user is prompted
 *                to provide their name, phone number, email address, and a password. They may choose
 *                an action button to register their new account and add their credentials to the
 *                user SQLite database or cancel the action and either way return to the login screen.
 *                This screen is designed to check no duplicate emails exist in the database, and
 *                ensure users fill in all the fields.
 */


public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton, CancelButton;
    EditText NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UsersSQL handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        NameHolder = findViewById(R.id.editTextUserName);
        PhoneNumberHolder = findViewById(R.id.editTextPhone);
        EmailHolder = findViewById(R.id.editTextEmail);
        PasswordHolder = findViewById(R.id.editTextPassword);
        RegisterButton = findViewById(R.id.registerSignupButton);
        CancelButton = findViewById(R.id.registerCancelButton);
        handler = new UsersSQL(this);

        // Adding click listener to register forgotPasswordButton
        RegisterButton.setOnClickListener(view -> {
            String message = verifyFields();
            if (!EmptyHolder) {
                // Check if email already exists in database
                verifyEmail();
                // Empty editText fields after done inserting in database
                clearFields();
            } 
            else {
                // Display toast message if any field is empty and focus the field
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to LoginActivity after cancel Register
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            this.finish();
        });
    }

    // Register new user into database
    public void addUser() {
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        User user = new User(name, phone, email, pass);
        handler.createUser(user);

        // Printing toast message after done inserting.
        Toast.makeText(RegisterActivity.this, "Thank you for registering!\n Log in to enter.", Toast.LENGTH_LONG).show();

        // Going back to LoginActivity after register success message
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        this.finish();
    }

    // Checking item description is not empty
    public String verifyFields() {

        // Getting value from fields and storing into string variable
        String message = "";
        String name = NameHolder.getText().toString().trim();
        String phone = PhoneNumberHolder.getText().toString().trim();
        String email = EmailHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        // Check to make sure fields are populated
        if (name.isEmpty()) {
            NameHolder.requestFocus();
            EmptyHolder = true;
            message = "Name is empty";
        }
        else if (phone.isEmpty()) {
            PhoneNumberHolder.requestFocus();
            EmptyHolder = true;
            message = "Phone number is empty";
        }
        else if (email.isEmpty()) {
            EmailHolder.requestFocus();
            EmptyHolder = true;
            message = "E-mail address is empty";
        }
        else if (pass.isEmpty()) {
            PasswordHolder.requestFocus();
            EmptyHolder = true;
            message = "Password is empty";
        }
        else {
            EmptyHolder = false;
        }
        return message;
    }

    // Check if user email already exists in database
    public void verifyEmail() {
        String email = EmailHolder.getText().toString().trim();
        db = handler.getWritableDatabase();
        // Adding search email query to cursor
        Cursor cursor = db.query(UsersSQL.TABLE_NAME, null, " " + UsersSQL.COLUMN_3_EMAIL + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If email exists then set result variable value as Email Found
                F_Result = "Email found";
                // Closing cursor.
                cursor.close();
            }
        }
        handler.close();
        // Calling method to check final result and insert data into SQLite database
        verifyCredentials();
    }

    // Check login credentials are correct
    public void verifyCredentials() {
        // Checking whether email is already in database
        if (F_Result.equalsIgnoreCase("Email found")) {
            // If email is exists then toast msg will display
            Toast.makeText(RegisterActivity.this, "Email already exists.", Toast.LENGTH_LONG).show();
        }
        else {
            // If email already doesn't exists then user registration details will entered to SQLite database
            addUser();
        }
        F_Result = "Not_Found";
    }

    // Empty edittext after done inserting in database
    public void clearFields() {
        NameHolder.getText().clear();
        PhoneNumberHolder.getText().clear();
        EmailHolder.getText().clear();
        PasswordHolder.getText().clear();
    }
}