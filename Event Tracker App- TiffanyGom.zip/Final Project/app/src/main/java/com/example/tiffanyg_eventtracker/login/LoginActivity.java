package com.example.tiffanyg_eventtracker.login;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tiffanyg_eventtracker.dashboard.EventDashActivity;
import com.example.tiffanyg_eventtracker.R;
import com.example.tiffanyg_eventtracker.databases.UsersSQL;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class activates the login functionality for the log in screen, which
 *               is the initial screen a user sees when they launch the app from their home screen.
 *               Here users input their email address and password and tap the sign in button to
 *               navigate to the dashboard. For new users, they have the option of taping the action
 *               button to navigate to the Register screen. For existing users who failed log in,
 *               they may retrieve their password by inputting the name and phone number registered
 *               under the account. To test the CRUD functionality of user credentials, the Retrieve
 *               activity screen is designed to display immediately a users password if a user enters
 *               the correct credentials to retrieve their password.
 */



public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button LoginButton, RegisterButton, ForgotPassButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    PopupWindow popWindow;
    SQLiteDatabase db;
    UsersSQL handler;
    String TempPassword = "NOT_FOUND";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        ForgotPassButton = findViewById(R.id.forgotPasswordButton);
        Email = findViewById(R.id.editTextEmail);
        Password = findViewById(R.id.editTextPassword);
        handler = new UsersSQL(this);

        // Adding click listener to sign in forgotPasswordButton
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            loginFunction();
        });

        // Adding click listener to register forgotPasswordButton.
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Adding click listener to register forgotPasswordButton.
        ForgotPassButton.setOnClickListener(view -> {
            EmailHolder = Email.getText().toString().trim();
            if (!EmailHolder.isEmpty()) {
                retrievePassPopup();
            }
            else {
                Toast.makeText(LoginActivity.this, "Please enter your email.", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login function
    public void loginFunction() {
        String message = verifyFields();
        if (!EmptyHolder) {
            // Opening SQLite database write permission
            db = handler.getWritableDatabase();
            // Adding search email query to cursor
            Cursor cursor = db.query(UsersSQL.TABLE_NAME, null, " " + UsersSQL.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();
                    // Storing Password and Name associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_2_PHONE_NUMBER));
                    // Closing cursor.
                    cursor.close();
                }
            }
            handler.close();
            // Calling method to check final result
            verifyFinalResult();
        }
        else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
    public String verifyFields() {
        // Getting value from fields and storing into string variable
        String message = "";
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();
        if (EmailHolder.isEmpty()) {
            Email.requestFocus();
            EmptyHolder = true;
            message = "Please enter your email.";
        }
        else if (PasswordHolder.isEmpty()) {
            Password.requestFocus();
            EmptyHolder = true;
            message = "Please enter your password.";
        }
        else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checking entered password from SQLite database email associated password
    public void verifyFinalResult() {
        if (TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this, "Login successful. Welcome!", Toast.LENGTH_SHORT).show();
            // Sending Name to EventsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);
            // Going to EventsListActivity after login success message
            Intent intent = new Intent(LoginActivity.this, EventDashActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
            this.finish();
            // Empty editText  after login successful and close database
            clearFields();
        }
        else {
            // Display error message if credentials are not correct
            Toast.makeText(LoginActivity.this, "Incorrect Email or Password .\n Please check your credentials and try again.", Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND";
    }

    // Empty edittext after login successful
    public void clearFields() {
        Email.getText().clear();
        Password.getText().clear();
    }

    // Popup for retrieve password
    public void retrievePassPopup() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_forgot_password, activity.findViewById(R.id.activity_forgot_password), false);

        //Create window for popup
        popWindow = new PopupWindow(layout, 900, 950, true);
        popWindow.showAtLocation(layout, Gravity.BOTTOM, 0, 0);

        EditText name = layout.findViewById(R.id.editTextUserName);
        EditText phone = layout.findViewById(R.id.editTextForgotPhone);
        TextView password = layout.findViewById(R.id.textViewPassDisplay);

        // Opening SQLite database write permission
        db = handler.getWritableDatabase();
        // Adding search email query to cursor
        Cursor cursor = db.query(UsersSQL.TABLE_NAME, null, " " + UsersSQL.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // Store Password and Name associated with email
                PhoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_2_PHONE_NUMBER));
                NameHolder = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_1_NAME));
                TempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQL.COLUMN_4_PASSWORD));

                // Close cursor
                cursor.close();
            }
        }
        handler.close();

        // Retrieve and cancel buttons
        Button retrieve = layout.findViewById(R.id.forgotRetrieveButton);
        Button cancel = layout.findViewById(R.id.forgotCancelButton);

        retrieve.setOnClickListener(view -> {
            String verifyName = name.getText().toString();
            String verifyPhone = phone.getText().toString();
            // Password retrieval is case sensitive. If user input is not found, a toast message is displayed prompting user to try again
            if (verifyPhone.equals(PhoneNumberHolder) && verifyName.equals(NameHolder)) {
                password.setText(TempPassword);
                new android.os.Handler().postDelayed(() -> popWindow.dismiss(), 3000);
            }
            else {
                Toast.makeText(activity, " Incorrect Name or Phone Number entered. Please try again.", Toast.LENGTH_LONG).show();
            }
        });
        // If cancel button is tapped, a toast message is displayed confirming action
        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Password not retrieved.", Toast.LENGTH_SHORT).show();
            popWindow.dismiss();
        });
    }
}