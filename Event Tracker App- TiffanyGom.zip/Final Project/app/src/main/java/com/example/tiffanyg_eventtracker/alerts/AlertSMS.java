package com.example.tiffanyg_eventtracker.alerts;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.tiffanyg_eventtracker.dashboard.EventDashActivity;
import com.example.tiffanyg_eventtracker.R;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class builds the pop up dialogue box that seeks permission from the user
 *               to activate SMS notification alerts, via their stored phone number, for their
 *               displayed events. The user is provided a positive button to grant permission
 *               and a negative button to deny permission.
 */



public class AlertSMS {

    public static AlertDialog doubleButton(final EventDashActivity context) {

        // Builder class for SMS permission request dialogue box
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_sms_title)
                .setIcon(R.drawable.button_sms)
                .setCancelable(false)
                .setMessage(R.string.alert_sms_msg)
                .setPositiveButton(R.string.alert_sms_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Notifications enabled!", Toast.LENGTH_LONG).show();
                    EventDashActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_sms_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Notifications disabled!", Toast.LENGTH_LONG).show();
                    EventDashActivity.DenySendSMS();
                    dialog.cancel();
                });

        // AlertDialog object return
        return builder.create();
    }
}
