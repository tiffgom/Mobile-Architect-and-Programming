package com.example.tiffanyg_eventtracker.alerts;

import androidx.appcompat.app.AlertDialog;

import com.example.tiffanyg_eventtracker.dashboard.EventDashActivity;
import com.example.tiffanyg_eventtracker.R;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Description: This class builds the pop up dialogue box that verifies with a user if they wish
 *               to delete all the events displayed in the dashboard. They are offered a positive
 *               button to delete and a negative button to cancel the action.
 */



public class AlertDeleteAll {

    public static AlertDialog doubleButton(final EventDashActivity context) {

        // Builder class for delete all dialogue box
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_delete_title)
                .setIcon(R.drawable.button_delete_all)
                .setCancelable(false)
                .setMessage(R.string.alert_delete_msg)
                .setPositiveButton(R.string.alert_delete_dialog_yes_button, (dialog, arg1) -> {
                    EventDashActivity.YesDeleteEvents();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_delete_dialog_no_button, (dialog, arg1) -> {
                    EventDashActivity.NoDeleteEvents();
                    dialog.cancel();
                });

        // AlertDialog object return
        return builder.create();
    }
}
