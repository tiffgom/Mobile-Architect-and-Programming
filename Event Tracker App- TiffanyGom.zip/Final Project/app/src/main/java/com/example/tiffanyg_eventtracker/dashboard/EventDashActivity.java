package com.example.tiffanyg_eventtracker.dashboard;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.tiffanyg_eventtracker.R;
import com.example.tiffanyg_eventtracker.alerts.AlertDeleteAll;
import com.example.tiffanyg_eventtracker.alerts.AlertSMS;
import com.example.tiffanyg_eventtracker.login.LoginActivity;
import com.example.tiffanyg_eventtracker.databases.EventsSQL;
import com.example.tiffanyg_eventtracker.tables.Event;

import java.util.ArrayList;

/*
 *  Name: Tiffany Gomez
 *  Course: CS-360-T6648
 *  Instructor: Professor Fry
 *  Date: 08/12/2022
 *  Assignment: 7-2 Project Three
 *  Description: This app is an event tracker app the fulfills client requirements by granting users Login & CRUD functionality.
 *               Users have the ability to Login into the app as new/existing users with options for password retrieval. The
 *               applications main dashboard gives users the ability to add multiple event entries, modify each entry, delete either
 *               a specific entry or the entire list, and activate or disable an SMS notification feature. Users can logout of the app
 *               or switch users to login with a different account. This app follows a MVC model with a controller that connects the
 *               interface to two databases. Each stores/retrieves/removes/updates user or event data.
 *   The Event Tracker app includes the following:
 *               1. Login Screen with:
 *                  a. Register New Account Screen
 *                  b. Retrieve Password Dialogue Box
 *               2. Dashboard Screen to display events with:
 *                  a. Template that updates values per entry added
 *                  b. New Event Screen
 *                  c. Modify Event Dialogue Box
 *                  d. Verify Delete All Events Dialogue Box
 *                  e. Request SMS Permission Dialogue Box
 *              3. SQLite Database for user accounts
 *              4. SQLite Database for event entries
 *              5. Drop down menu from top app bar with:
 *                  a. Log out action
 *                  b. Switch user action
 *
 *  This class is the app's dashboard and main activity screen. From this screen users can navigate and access
 *  every app feature after a successful login.
 */


@SuppressWarnings("ALL")
public class EventDashActivity extends AppCompatActivity {

    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    static String NameHolder, EmailHolder, PhoneNumberHolder;
    private static boolean smsAuthorized = false;
    private static boolean deleteEvents = false;
    ImageButton buttonAddEvent, buttonSMS, buttonDeleteEvent;
    ListView trackerListView;
    EventsSQL db;
    AlertDialog AlertDialog = null;
    ArrayList<Event> events;
    EventList customEventsList;
    int eventsCount;

    // Delete All events dialogue box user response
    public static void YesDeleteEvents() {
        deleteEvents = true;
    }
    public static void NoDeleteEvents() {
        deleteEvents = false;
    }

    // SMS Notification Permission dialogue box user response
    public static void AllowSendSMS() {
        smsAuthorized = true;
    }
    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    // Message sent to users
    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumberHolder;
        String smsMsg = "Hello, this is your Event Tracker App! \n Please log in to see your upcoming event.";

        // Toast Message for SMS Permission user response
        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS sent!", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device permission not granted.", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "SMS Notifications disabled!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Activate dashboard buttons, textViews, and editText variables
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonSMS = findViewById(R.id.buttonSMS);
        buttonDeleteEvent = findViewById(R.id.buttonDeleteAll);
        trackerListView = findViewById(R.id.trackerListView);
        db = new EventsSQL(this);

        // Receive user login information for account
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumberHolder = bundle.getString("user_phone");
        }

        // Retrieve user event entries
        events = (ArrayList<Event>) db.getAllEvents();
        eventsCount = db.getEventsCount();
        if (eventsCount > 0) {
            customEventsList = new EventList(this, events, db);
            trackerListView.setAdapter(customEventsList);
        }
        else {
            Toast.makeText(this, "Database is empty", Toast.LENGTH_LONG).show();
        }

        // Adding click listener to buttonAddEvent
        buttonAddEvent.setOnClickListener(view -> {
            // Opening new AddEventActivity
            Intent add = new Intent(this, CreateEventActivity.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1);
        });

        // Adding click listener to buttonSMS
        buttonSMS.setOnClickListener(view -> {
            // Request SMS permissions for the device
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this, "SMS permission is required", Toast.LENGTH_LONG).show();
                }
                else {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            }
            else {
                Toast.makeText(this, "SMS Notifications enabled!", Toast.LENGTH_LONG).show();
            }
            // Open SMS Alert Dialog
            AlertDialog = AlertSMS.doubleButton(this);
            AlertDialog.show();
        });

        // Adding click listener to buttonDeleteAll
        buttonDeleteEvent.setOnClickListener(view -> {
            eventsCount = db.getEventsCount();
            if (eventsCount > 0) {
                // Open Delete Alert Dialog
                AlertDialog = AlertDeleteAll.doubleButton(this);
                AlertDialog.show();
                AlertDialog.setCancelable(true);
                AlertDialog.setOnCancelListener(dialog -> deleteAllEvents());
            }
            else {
                Toast.makeText(this, "There are no events to delete.", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Create menu in AppBar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_event_menu, menu);
        return true;
    }

    // Menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            // End EventsListActivity on menu button click for user log out action
            db.close();
            Toast.makeText(this, "Logging out...Goodbye, see you soon!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(EventDashActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return true;
        }
        // End EventsListActivity on menu button click for user switch user account action
        if (item.getItemId() == R.id.action_switch) {
            db.close();
            Toast.makeText(this, "Log in with a different user.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(EventDashActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Actions for New Event: Add or cancel action
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                eventsCount = db.getEventsCount();
                if (customEventsList == null) {
                    customEventsList = new EventList(this, events, db);
                    trackerListView.setAdapter(customEventsList);
                }
                customEventsList.events = (ArrayList<Event>) db.getAllEvents();
                ((BaseAdapter) trackerListView.getAdapter()).notifyDataSetChanged();
            }
            else {
                Toast.makeText(this, "No event added.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Delete all events toast confirmation
    public void deleteAllEvents() {
        if (deleteEvents) {
            db.deleteAllEvents();
            Toast.makeText(this, "All events deleted.", Toast.LENGTH_SHORT).show();
            if (customEventsList == null) {
                customEventsList = new EventList(this, events, db);
                trackerListView.setAdapter(customEventsList);
            }
            customEventsList.events = (ArrayList<Event>) db.getAllEvents();
            ((BaseAdapter) trackerListView.getAdapter()).notifyDataSetChanged();
        }
    }
}